package com.usercode.service.test;

import org.apache.commons.lang.RandomStringUtils;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.runners.MockitoJUnitRunner;

import com.usercode.beans.UserCodeResponse;
import com.usercode.dao.IUserCodeDAO;
import com.usercode.entities.UserCode;
import com.usercode.exception.UserCodeException;
import com.usercode.service.UserCodeService;

@RunWith(MockitoJUnitRunner.class)
public class UserCodeServiceTest {

	@InjectMocks
	private UserCodeService userCodeService;

	@Mock
	private IUserCodeDAO userCodeDAO;

	@Before
	public void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
	}

	@Test
	public void deleteUserCodePositiveTest1() {
		userCodeService.deleteUserCode(1);
		Mockito.verify(userCodeDAO, Mockito.times(1)).deleteUserCode(Mockito.anyInt());
	}

	@Test
	public void updateUserCodePostiveTest2() throws UserCodeException {

		Mockito.when(userCodeDAO.updateUserCode(Mockito.any())).thenReturn("abc123");

		UserCodeResponse userCode = userCodeService.updateUserCode(1);
		Assert.assertEquals("abc123", userCode.getCode());
		Assert.assertEquals(1, userCode.getResultCode());
		Assert.assertEquals("successful", userCode.getMessage());
	}

	@Test
	public void updateUserCodeNegativeTest3() throws UserCodeException {

		Mockito.when(userCodeDAO.updateUserCode(Mockito.any())).thenThrow(UserCodeException.class);

		UserCodeResponse userCode = userCodeService.updateUserCode(1);
		Assert.assertEquals(0, userCode.getResultCode());
		Assert.assertEquals("error", userCode.getMessage());
	}

	@Test
	public void verifyUserCodePostiveTest4() throws UserCodeException {

		UserCode userCode = new UserCode();
		userCode.setCode("abc123");
		userCode.setUserid(1);
		Mockito.when(userCodeDAO.verifyUserCode(Mockito.any())).thenReturn(userCode);

		UserCodeResponse userCodeResponse = userCodeService.verifyUserCode(1,"abc123");
		Assert.assertEquals(1, userCodeResponse.getResultCode());
		Assert.assertEquals("true", userCodeResponse.getValid());
	}

	@Test
	public void verifyUserCodePostiveTest5() throws UserCodeException {

		Mockito.when(userCodeDAO.verifyUserCode(Mockito.any())).thenReturn(null);

		UserCodeResponse userCodeResponse = userCodeService.verifyUserCode(1,"abc123");
		Assert.assertEquals(1, userCodeResponse.getResultCode());
		Assert.assertEquals("", userCodeResponse.getValid());
	}
	
	@Test
	public void verifyUserCodeNegativeTest6() throws UserCodeException {

		UserCode userCode = new UserCode();
		userCode.setCode("abc123");
		userCode.setUserid(1);
		Mockito.when(userCodeDAO.verifyUserCode(Mockito.any())).thenThrow(UserCodeException.class);

		UserCodeResponse userCodeResponse = userCodeService.verifyUserCode(1,"abc123");
		Assert.assertEquals(0, userCodeResponse.getResultCode());
		Assert.assertEquals("false", userCodeResponse.getValid());
	}
	
}