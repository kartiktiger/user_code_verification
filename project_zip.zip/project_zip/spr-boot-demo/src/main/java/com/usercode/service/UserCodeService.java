package com.usercode.service;

import org.apache.commons.lang.RandomStringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.usercode.beans.UserCodeResponse;
import com.usercode.dao.IUserCodeDAO;
import com.usercode.entities.UserCode;
import com.usercode.exception.UserCodeException;
@Service
public class UserCodeService implements IUserCodeService {
	@Autowired
	private IUserCodeDAO userCodeDAO;

	@Override
	public UserCodeResponse verifyUserCode(Integer userId, String code) {
		UserCodeResponse userCodeResponse = new UserCodeResponse();
		UserCode userCode = new UserCode();
		userCode.setUserid(userId);
		userCode.setCode(code);
		try {
			UserCode userCodeObj = userCodeDAO.verifyUserCode(userCode);
			userCodeResponse.setResultCode(1);
			if(userCodeObj!=null && userCodeObj.getCode()!=null)
			{
				userCodeResponse.setValid("true");
			}
			else 
			{
				userCodeResponse.setValid("");
			}
		} catch (UserCodeException e) {
			userCodeResponse.setResultCode(0);
			userCodeResponse.setValid("false");
		}
		deleteUserCode(userId);
		return userCodeResponse;
	}
	@Override
	public UserCodeResponse updateUserCode(int userId) {
		UserCodeResponse userCodeResponse = new UserCodeResponse();
		UserCode userCode = new UserCode();
		userCode.setUserid(userId);
		String code = RandomStringUtils.random(6,true, true);
		userCode.setCode(code);
		try
		{
		userCodeResponse.setCode(userCodeDAO.updateUserCode(userCode));
		userCodeResponse.setResultCode(1);
		userCodeResponse.setMessage("successful");
		}
		catch(UserCodeException ex)
		{
			userCodeResponse.setResultCode(0);
			userCodeResponse.setMessage("error");
		}
		
		return userCodeResponse;
	}
	
	@Override
	public void deleteUserCode(int userId) {
		userCodeDAO.deleteUserCode(userId);
	}
}
