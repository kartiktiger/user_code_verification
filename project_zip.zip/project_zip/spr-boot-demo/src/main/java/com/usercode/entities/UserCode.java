package com.usercode.entities;
import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table(name="user_code")
public class UserCode implements Serializable { 
	private static final long serialVersionUID = 1L;
	@Id
	@Column(name="userid")
    private int userid;  
	@Column(name="code")
    private String code;
	
	public int getUserid() {
		return userid;
	}
	public void setUserid(int userid) {
		this.userid = userid;
	}
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}

} 