package com.usercode.service;

import com.usercode.beans.UserCodeResponse;

public interface IUserCodeService {
     UserCodeResponse updateUserCode(int userId);
     void deleteUserCode(int userId);
	 UserCodeResponse verifyUserCode(Integer userId, String userCode);
}
