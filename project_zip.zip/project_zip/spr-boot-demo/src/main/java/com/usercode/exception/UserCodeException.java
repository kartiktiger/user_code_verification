package com.usercode.exception;

public class UserCodeException extends Exception{

	private static final long serialVersionUID = 1L;

	public UserCodeException() {
		super();
	}

	public UserCodeException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
	}

	public UserCodeException(String message, Throwable cause) {
		super(message, cause);
	}

	public UserCodeException(String message) {
		super(message);
	}

	public UserCodeException(Throwable cause) {
		super(cause);
	}

	
}
