package com.usercode.dao;
import java.util.List;

import com.usercode.entities.UserCode;
import com.usercode.exception.UserCodeException;
public interface IUserCodeDAO {

	UserCode verifyUserCode(UserCode userCode) throws UserCodeException;
    String updateUserCode(UserCode userCode) throws UserCodeException;
    void deleteUserCode(int userId);
    UserCode getUserCodeByUserId(int userid);
}
 