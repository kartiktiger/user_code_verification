package com.usercode.controller;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.usercode.beans.UserCodeResponse;
import com.usercode.service.IUserCodeService;

@Controller
@RequestMapping("verification_code")
public class UserCodeController {
	@Autowired
	private IUserCodeService userCodeService;

	 @RequestMapping(path="{userId}/{code}", method= RequestMethod.GET)
	 public ResponseEntity<UserCodeResponse> verifyUserCode(@PathVariable("userId") Integer userId, @PathVariable("code") String code){
	    	 UserCodeResponse userCodeResponse = userCodeService.verifyUserCode(userId, code);
			return new ResponseEntity<UserCodeResponse>(userCodeResponse, HttpStatus.OK);
	    }
	 
	@RequestMapping(path="{userId}", method= RequestMethod.POST)
	public ResponseEntity<UserCodeResponse> updateUserCode(@PathVariable("userId") Integer userId) {
		if(userId!=1 && userId!=10)
		{ 
			UserCodeResponse userCodeRes = new UserCodeResponse();
			userCodeRes.setResultCode(0);
			userCodeRes.setMessage("Please enter userId as either 1 or 10");
			return new ResponseEntity<UserCodeResponse>(userCodeRes, HttpStatus.OK);
		}
		UserCodeResponse userCodeResponse = userCodeService.updateUserCode(userId);
		return new ResponseEntity<UserCodeResponse>(userCodeResponse, HttpStatus.OK);
	}
} 