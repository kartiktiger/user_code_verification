package com.usercode.dao;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.usercode.entities.UserCode;
import com.usercode.exception.UserCodeException;

@Transactional
@Repository
public class UserCodeDAO implements IUserCodeDAO {
	@PersistenceContext	
	private EntityManager entityManager;	
	
	@Override
	public UserCode getUserCodeByUserId(int userid) {
		return entityManager.find(UserCode.class, userid);
	}

	@Override
	public UserCode verifyUserCode(UserCode userCode) throws UserCodeException {
		String hql = "FROM UserCode as us WHERE us.userid =" +userCode.getUserid() + " and us.code ='" + userCode.getCode()+"'";
		System.out.println("hql : "+hql);
		UserCode userCodeDB=null;
		try
		{
			userCodeDB = (UserCode) entityManager.createQuery(hql).getResultList().get(0);
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
			throw new UserCodeException("Error in verifying user's code",ex);
		}
		return userCodeDB;
	}
	@Override
	public String updateUserCode(UserCode userCode) throws UserCodeException {
		UserCode userCodeDB = null;
		try
		{
		userCodeDB = getUserCodeByUserId(userCode.getUserid());
		userCodeDB.setCode(userCode.getCode());
		entityManager.flush();
		}
		catch(Exception ex)
		{
			throw new UserCodeException("Error in updating user's verification code",ex);
		}
        return userCodeDB.getCode();
	}
	@Override
	public void deleteUserCode(int userId) {
		UserCode userCodeDB = getUserCodeByUserId(userId);
		userCodeDB.setCode(null);
		entityManager.flush();
	}
}
